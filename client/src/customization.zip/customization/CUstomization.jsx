import React from "react";

const CUstomization = () => {
  return <div>CUstomization</div>;
};

export default CUstomization;
